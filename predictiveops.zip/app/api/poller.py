"""Background poller: Prometheus -> sample clock -> shared ingestion path."""

from __future__ import annotations

import threading
import time
from datetime import UTC, datetime

from app.api.deps import production_model_block_reason
from app.api.ingestion import collect_points
from app.api.state import ApiState
from app.core.logging import get_logger
from app.models.predictor import Predictor
from app.models.schemas import MetricPoint
from app.services.prometheus_client import PrometheusClient, frame_to_points

log = get_logger(__name__)


class PrometheusPoller:
    def __init__(self, state: ApiState, client: PrometheusClient, services: list[str], *,
                 step_seconds: float, interval_seconds: float, lookback_steps: int,
                 clock=time.time, scope: str = "combined",
                 predictor: Predictor | None = None) -> None:
        self.state, self.client, self.services = state, client, services
        self.step, self.interval, self.steps = step_seconds, interval_seconds, lookback_steps
        self.scope, self.predictor = scope, predictor
        self._clock = clock
        self._sample_origin_ts = (self._clock() // self.step) * self.step
        self._sample_origin_dt = datetime.fromtimestamp(self._sample_origin_ts, UTC)
        self.status: dict[str, dict] = {
            s: {
                "last_poll": None,
                "last_ok": None,
                "error": None,
                "inference_error": None,
                "samples_ingested": 0,
            }
            for s in services
        }
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def poll_once(self) -> None:
        for svc in self.services:
            st = self.status[svc]
            st["last_poll"] = datetime.now(UTC).isoformat(timespec="seconds")
            try:
                raw = self.client.fetch_window(
                    svc,
                    end=self._clock(),
                    steps=self.steps,
                    step_seconds=self.step,
                )
                df = self.client.to_sample_clock(
                    raw,
                    self.step,
                    origin_ts=self._sample_origin_ts,
                    origin_sample_ts=self._sample_origin_dt,
                )
                if df.empty:
                    raise RuntimeError("no complete samples returned for this service")

                series_id = svc if self.scope == "combined" else f"{self.scope}:{svc}"
                samples = [MetricPoint(**p) for p in frame_to_points(df)]

                # Determine inference eligibility independently of collection.
                predictor = (
                    self.predictor
                    or self.state.scope_predictors.get(self.scope)
                    or self.state.predictor
                )
                try:
                    reason = production_model_block_reason(
                        self.state,
                        predictor,
                        expected_scope=self.scope if self.scope != "combined" else None,
                    )
                    if predictor is None or reason is not None:
                        inference_error = reason or "no champion model loaded"
                        predictor = None
                    else:
                        inference_error = None
                except Exception as exc:
                    predictor = None
                    inference_error = f"{type(exc).__name__}: {exc}"

                # Buffering and optional scoring are atomic with respect to
                # other ingestion requests. Scoring failures do not undo samples.
                outcome, scoring_error = collect_points(
                    self.state,
                    series_id,
                    samples,
                    predictor=predictor,
                )

                st["samples_ingested"] += outcome.accepted
                st["last_ok"], st["error"] = st["last_poll"], None

                if scoring_error is not None:
                    inference_error = (
                        f"{type(scoring_error).__name__}: {scoring_error}"
                    )
                st["inference_error"] = inference_error

            except Exception as exc:  # source failures must never stop the poller or API
                st["error"] = f"{type(exc).__name__}: {exc}"
                log.warning(
                    "prometheus poll failed",
                    extra={"service": svc, "error": st["error"]},
                )

    def _loop(self) -> None:
        while not self._stop.is_set():
            self.poll_once()
            self._stop.wait(self.interval)

    def start(self) -> None:
        self._thread = threading.Thread(target=self._loop, daemon=True, name="prometheus-poller")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
